<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <div id="app">
            <loading ref="loading"></loading>
            <app-header ref="header"></app-header>
            <transition name="faderouterfront" mode="out-in">
                <router-view :key="$route.path" class="app-content"></router-view>
            </transition>
            <app-footer ref="footer"></app-footer>
        </div>
        <?php echo $__env->make('scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        

    </body>
</html>
